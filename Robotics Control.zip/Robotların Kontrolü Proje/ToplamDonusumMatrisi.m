syms theta1 theta2 theta3 a1 a2 a3 real

% DH'ye göre her bir dönüşüm matrisi:
T01 = [cos(theta1), -sin(theta1), 0, a1*cos(theta1);
       sin(theta1),  cos(theta1), 0, a1*sin(theta1);
       0,            0,           1, 0;
       0,            0,           0, 1];

T12 = [cos(theta2), -sin(theta2), 0, a2*cos(theta2);
       sin(theta2),  cos(theta2), 0, a2*sin(theta2);
       0,            0,           1, 0;
       0,            0,           0, 1];

T23 = [cos(theta3), -sin(theta3), 0, a3*cos(theta3);
       sin(theta3),  cos(theta3), 0, a3*sin(theta3);
       0,            0,           1, 0;
       0,            0,           0, 1];

% Toplam dönüşüm matrisi:
T03 = simplify(T01 * T12 * T23);

% Sonucu yazdır:
disp('T03 = ');
disp(T03);
