function dx = pd_control_rhs(t, x, qd, dqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Güvenli zaman indeksleme
    t_step = 0.01;
    idx = min(size(qd,2), max(1, round(t / t_step) + 1));
    
    qd_i = qd(:,idx);
    dqd_i = dqd(:,idx);

    % PD kontrol
    e = qd_i - q;
    edot = dqd_i - dq;

    tau = Kp * e + Kd * edot;

    % Dinamik model
    M = inertia_matrix(q, params);
    Cqdot = zeros(3,1);  % sadeleştirme
    G = zeros(3,1);      % sadeleştirme

    ddq = M \ (tau - Cqdot - G);

    dx = [dq; ddq];
end
