clear; clc;
params.a = [1.0; 1.0; 0.8];
params.m = [2.0; 1.5; 1.0];
params.g = 9.81;
params.I = 1/12 * params.m .* params.a.^2;
a1 = params.a(1); a2 = params.a(2); a3 = params.a(3);

T = 15; dt = 0.01;
[xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, t] = generate_circle_trajectory(T, dt, 0.3, 1.3, 0.0, 0.5);
[qd, qd_dot, ~] = inverse_kinematics_rrr_timevarying(xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, params);

Kp = diag([60, 60, 50]);
Kd = diag([10, 10, 8]);

x0 = [qd(:,1); zeros(3,1)];
rhs = @(t, x) gravity_pd_rhs(t, x, qd, qd_dot, Kp, Kd, params);
[t_out, x_out] = ode45(rhs, t, x0);

q_out = x_out(:,1:3)';
x_ee = a1*cos(q_out(1,:)) + a2*cos(q_out(1,:) + q_out(2,:)) + a3*cos(sum(q_out,1));
y_ee = a1*sin(q_out(1,:)) + a2*sin(q_out(1,:) + q_out(2,:)) + a3*sin(sum(q_out,1));

figure;
subplot(2,1,1); plot(xd, yd, 'k--', 'LineWidth', 2); title('Desired Trajectory'); axis equal; grid on; xlabel('X [m]'); ylabel('Y [m]');
subplot(2,1,2); plot(x_ee, y_ee, 'r-', 'LineWidth', 2); title('Actual Trajectory - Gravity+PD'); axis equal; grid on; xlabel('X [m]'); ylabel('Y [m]');

ex = xd - x_ee;
ey = yd - y_ee;
rms_xy = sqrt(mean(ex.^2 + ey.^2));
fprintf('--- RMS End-Effector Error (Gravity+PD) ---\n');
fprintf('RMS Position Error: %.4f m\n', rms_xy);
