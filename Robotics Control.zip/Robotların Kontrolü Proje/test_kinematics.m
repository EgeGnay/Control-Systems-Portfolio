
% Forward Kinematics Test Without Dynamics
clear; clc;

% Parameters
params.a1 = 1.0; params.a2 = 1.0; params.a3 = 0.5;

% Trajectory for each joint (no dynamics)
theta1 = linspace(deg2rad(10), deg2rad(15), 100)';
theta2 = linspace(deg2rad(10), deg2rad(15), 100)';
theta3 = linspace(deg2rad(-5), deg2rad(-10), 100)';

x = zeros(100,1);
y = zeros(100,1);
phi = zeros(100,1);

for i = 1:100
    [x(i), y(i), phi(i)] = forward_kinematics([theta1(i); theta2(i); theta3(i)], params);
end

% Plot the end-effector trajectory
figure;
plot(x, y, 'b', 'LineWidth', 2);
xlabel('x (m)'); ylabel('y (m)'); grid on;
title('End-Effector Trajectory from Forward Kinematics');
