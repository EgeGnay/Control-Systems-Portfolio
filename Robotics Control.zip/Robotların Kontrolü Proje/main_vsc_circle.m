clear; clc;

% --- Sistem parametreleri ---
params.a = [1.0; 1.0; 0.8];
params.m = [2.0; 1.5; 1.0];
params.g = 9.81;
params.I = 1/12 * params.m .* params.a.^2;
a1 = params.a(1); a2 = params.a(2); a3 = params.a(3);

% --- VSC kontrol parametreleri ---
lambda = diag([10, 10, 8]);
Ks = diag([50, 40, 30]);
epsilon = 0.01;

% --- Dairesel uç-efektör trajesi tanımı ---
T = 15; dt = 0.01;
[xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, t] = generate_circle_trajectory(T, dt, 0.3, 1.3, 0.0, 0.5);
[qd_all, dqd_all, ddqd_all] = inverse_kinematics_rrr_timevarying(xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, params);

% Boyut düzeltme (qd_all zaten 3xN)
qd_all = qd_all';     % [N x 3]
dqd_all = dqd_all';
ddqd_all = ddqd_all';

% Vektör uzunluğu kontrolü
n = length(t);
qd_all = qd_all(1:n, :);
dqd_all = dqd_all(1:n, :);
ddqd_all = ddqd_all(1:n, :);

% --- Başlangıç durumu ---
x0 = [qd_all(1,:)'; zeros(3,1)];

% --- Interpolasyon fonksiyonları ---
qd_func   = @(tt) interp1(t, qd_all, tt, 'linear', 'extrap')';
dqd_func  = @(tt) interp1(t, dqd_all, tt, 'linear', 'extrap')';
ddqd_func = @(tt) interp1(t, ddqd_all, tt, 'linear', 'extrap')';

% --- RHS tanımı ---
rhs = @(t, x) vsc_control_rhs_circle(t, x, ...
    qd_func(t), dqd_func(t), ddqd_func(t), ...
    lambda, Ks, epsilon, params);

% --- ODE çözümü ---
[t_out, x_out] = ode45(rhs, t, x0);

q_out = x_out(:,1:3)';

% --- End-effector pozisyonu ---
x_ee = a1*cos(q_out(1,:)) + a2*cos(q_out(1,:)+q_out(2,:)) + a3*cos(sum(q_out,1));
y_ee = a1*sin(q_out(1,:)) + a2*sin(q_out(1,:)+q_out(2,:)) + a3*sin(sum(q_out,1));

% --- Grafikler ---
figure;
subplot(2,1,1);
plot(xd, yd, 'k--', 'LineWidth', 2); title('Desired Trajectory');
xlabel('X [m]'); ylabel('Y [m]'); axis equal; grid on;

subplot(2,1,2);
plot(x_ee, y_ee, 'r-', 'LineWidth', 2); title('Actual Trajectory - VSC');
xlabel('X [m]'); ylabel('Y [m]'); axis equal; grid on;

% --- RMS Hata ---
ex = xd - x_ee;
ey = yd - y_ee;
rms_xy = sqrt(mean(ex.^2 + ey.^2));
fprintf('--- RMS End-Effector Error (VSC) ---\n');
fprintf('RMS Position Error: %.4f m\n', rms_xy);
