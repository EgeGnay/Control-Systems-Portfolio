function dx = gravity_control_rhs(~, x, qd, dqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Hata terimleri
    e = qd - q;
    edot = dqd - dq;

    % Yerçekimi + PD kontrolü
    G = gravity_vector(q, params);
    tau = G + Kp * e + Kd * edot;

    % Hareket denklemi
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    ddq = M \ (tau - Cqdot - G);  % G qeşitli yönlerden dengelenir

    dx = [dq; ddq];
end
