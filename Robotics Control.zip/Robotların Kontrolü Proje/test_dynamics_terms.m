
% Test of dynamic terms M, C, G
clear; clc;

% Define parameters
params.a1 = 1.0; params.a2 = 1.0; params.a3 = 0.5;
params.m1 = 0.5; params.m2 = 0.3; params.m3 = 0.2;
params.I1 = 0.001; params.I2 = 0.001; params.I3 = 0.0005;
params.g = 9.81;
params.theta_d = deg2rad([15; 15; -10]);
params.Kp = diag([10 10 10]);
params.Kd = diag([2 2 2]);

% Joint state
q = deg2rad([14; 14; -9]);
dq = [0; 0; 0];

% Compute M, C, G from dynamics_rhs internal formulas
theta = q; dtheta = dq;
t12 = theta(1)+theta(2);
t123 = t12+theta(3);
c2 = cos(theta(2)); c3 = cos(theta(3)); s2 = sin(theta(2));

% M(q)
M11 = params.I1 + params.I2 + params.I3 + ...
      params.m1*(params.a1^2)/4 + ...
      params.m2*(params.a1^2 + (params.a2^2)/4 + params.a1*params.a2*c2) + ...
      params.m3*(params.a1^2 + params.a2^2 + (params.a3^2)/4 + ...
      params.a1*params.a2*c2 + params.a1*params.a3*cos(t123) + params.a2*params.a3*c3);
M12 = params.I2 + params.I3 + ...
      params.m2*((params.a2^2)/4 + params.a1*params.a2*c2) + ...
      params.m3*(params.a2^2 + (params.a3^2)/4 + params.a1*params.a2*c2 + params.a2*params.a3*c3);
M13 = params.I3 + ...
      params.m3*((params.a3^2)/4 + params.a1*params.a3*cos(t123) + params.a2*params.a3*c3);
M22 = params.I2 + params.I3 + ...
      params.m2*(params.a2^2)/4 + ...
      params.m3*(params.a2^2 + (params.a3^2)/4 + params.a2*params.a3*c3);
M23 = params.I3 + ...
      params.m3*((params.a3^2)/4 + params.a2*params.a3*c3);
M33 = params.I3 + ...
      params.m3*(params.a3^2)/4;

M = [M11 M12 M13; M12 M22 M23; M13 M23 M33];

% C(q,dq)
C = [
  -params.m2*params.a1*params.a2*s2*dtheta(2)*(2*dtheta(1)+dtheta(2)) - ...
   params.m3*params.a2*params.a3*sin(theta(3))*dtheta(3)*(2*dtheta(2)+dtheta(3));
  params.m2*params.a1*params.a2*s2*dtheta(1)^2 + ...
   params.m3*params.a2*params.a3*sin(theta(3))*dtheta(3)^2;
  0
];

% G(q)
G = [
  params.g*(params.m1*params.a1/2 + params.m2*params.a1 + params.m3*params.a1)*cos(theta(1)) + ...
  params.g*(params.m2*params.a2/2 + params.m3*params.a2)*cos(t12) + ...
  params.g*(params.m3*params.a3/2)*cos(t123);
  params.g*(params.m2*params.a2/2 + params.m3*params.a2)*cos(t12) + ...
  params.g*(params.m3*params.a3/2)*cos(t123);
  params.g*(params.m3*params.a3/2)*cos(t123)
];

% Display outputs
disp('Inertia matrix M(q):'); disp(M);
disp('Coriolis vector C(q,dq):'); disp(C);
disp('Gravity vector G(q):'); disp(G);
