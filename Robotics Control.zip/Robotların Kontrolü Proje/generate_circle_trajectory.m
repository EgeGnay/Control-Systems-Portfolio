function [xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, t] = generate_circle_trajectory(T, dt, r, xc, yc, omega)
    t = 0:dt:T;
    xd = xc + r * cos(omega * t);
    yd = yc + r * sin(omega * t);

    xd_dot = -r * omega * sin(omega * t);
    yd_dot = r * omega * cos(omega * t);

    xd_ddot = -r * omega^2 * cos(omega * t);
    yd_ddot = -r * omega^2 * sin(omega * t);
end
