function [qd, qd_dot, qd_ddot] = inverse_kinematics_rrr_timevarying(xd, yd, xd_dot, yd_dot, xd_ddot, yd_ddot, params)
    dt = 0.01;
    n = length(xd);
    qd = zeros(3, n);
    phi_d = pi/2 * ones(1, n);

    for k = 1:n
        xw = xd(k) - params.a(3) * cos(phi_d(k));
        yw = yd(k) - params.a(3) * sin(phi_d(k));
        D = (xw^2 + yw^2 - params.a(1)^2 - params.a(2)^2) / (2 * params.a(1) * params.a(2));
        if abs(D) > 1
            warning("Unreachable point at t = %.2f", k*dt);
            continue
        end
        theta2 = atan2(sqrt(1 - D^2), D);
        beta = atan2(yw, xw);
        psi = atan2(params.a(2)*sin(theta2), params.a(1) + params.a(2)*cos(theta2));
        theta1 = beta - psi;
        theta3 = phi_d(k) - theta1 - theta2;
        qd(:,k) = [theta1; theta2; theta3];
    end

    qd_dot = [zeros(3,1), diff(qd,1,2)/dt];
    qd_ddot = [zeros(3,2), diff(qd_dot,1,2)/dt];
end
