function dx = vsc_control_rhs(~, x, qd, dqd, ddqd, lambda, Ks, epsilon, params)
    q = x(1:3);
    dq = x(4:6);

    e = q - qd;
    edot = dq - dqd;
    s = edot + lambda * e;
    sat_s = tanh(s / epsilon);  % smoothing sign()

    v = ddqd - lambda * edot - Ks * sat_s;

    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);

    tau = M * v + Cqdot + G;
    ddq = M \ (tau - Cqdot - G);

    dx = [dq; ddq];
end
