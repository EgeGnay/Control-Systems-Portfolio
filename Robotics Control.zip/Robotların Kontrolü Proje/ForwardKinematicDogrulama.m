% 📌 Eklemlerin açıları (derece → rad)
theta1 = deg2rad(30);    % θ1 = 30°
theta2 = deg2rad(45);    % θ2 = 45°
theta3 = deg2rad(-15);   % θ3 = -15°

% 📏 Bağlantı uzunlukları
a1 = 1.0;  % metre
a2 = 1.0;  % metre
a3 = 0.5;  % metre

% 🔹 Toplam açıları tanımla
theta12 = theta1 + theta2;
theta123 = theta12 + theta3;

% 📐 Uç efektör pozisyonu
x = a1*cos(theta1) + a2*cos(theta12) + a3*cos(theta123);
y = a1*sin(theta1) + a2*sin(theta12) + a3*sin(theta123);

% 📐 Yönelim açısı
phi = theta123;

% 🎯 Sonuçları yazdır
fprintf('End-effector position:\n');
fprintf('x = %.3f m\n', x);
fprintf('y = %.3f m\n', y);
fprintf('phi = %.3f rad (%.2f deg)\n', phi, rad2deg(phi));
