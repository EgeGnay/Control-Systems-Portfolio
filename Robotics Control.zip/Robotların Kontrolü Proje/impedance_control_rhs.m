function dx = impedance_control_rhs(~, x, qd, dqd, ddqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Hata terimleri
    e = q - qd;
    edot = dq - dqd;

    % Hedef ivme - yay - sönüm
    v = ddqd - Kd * edot - Kp * e;

    % Dinamik hesaplamalar
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);

    % Net moment
    tau = M * v + Cqdot + G;

    % Durum türevleri
    ddq = M \ (tau - Cqdot - G);
    dx = [dq; ddq];
end
