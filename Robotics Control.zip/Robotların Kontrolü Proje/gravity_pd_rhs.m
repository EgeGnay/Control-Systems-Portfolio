function dx = gravity_pd_rhs(~, x, qd, dqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Global adım sayacını tutmak için persistent indeks
    persistent idx
    if isempty(idx)
        idx = 1;
    else
        idx = min(idx + 1, size(qd, 2)); % Sınırı aşmamak için
    end

    % Zamanla değişen referansları al
    qd_t = qd(:, idx);
    dqd_t = dqd(:, idx);

    % Hata terimleri
    e = qd_t - q;
    edot = dqd_t - dq;

    % Yerçekimi + PD kontrolü
    G = gravity_vector(q, params);
    tau = G + Kp * e + Kd * edot;

    % Hareket denklemi
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    ddq = M \ (tau - Cqdot - G);  % G zaten tau içinde olduğu için net etki

    dx = [dq; ddq];
end
