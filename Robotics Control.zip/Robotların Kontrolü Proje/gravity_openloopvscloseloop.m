% Open Loop ve Gravity Compensation Simülasyonu
clc; clear; close all;

q0 = deg2rad([14 5 -9]);   % GÜNCEL başlangıç eklem açıları (radyan)
qd0 = [0 0 0];             % Başlangıç hızlar

dt = 0.01; T = 5; steps = T/dt;

% Açılar ve hızlar için kayıt matrisleri
q_open = q0; qd_open = qd0; q_hist_open = zeros(steps,3);
q_grav = q0; qd_grav = qd0; q_hist_grav = zeros(steps,3);

for i = 1:steps
    % --- Open loop (tau = 0) ---
    tau_open = [0; 0; 0];
    Gq_open = GravityVector(q_open);
    Mq_open = InertiaMatrix(q_open);
    % M(q) * qdd + G(q) = 0 => qdd = -inv(M(q))*G(q)
    qdd_open = -Mq_open \ Gq_open;
    qd_open = qd_open + qdd_open' * dt;
    q_open = q_open + qd_open * dt;
    q_hist_open(i,:) = q_open;

    % --- Gravity Compensation (tau = G(q)) ---
    Gq_grav = GravityVector(q_grav);
    tau_grav = Gq_grav;
    Mq_grav = InertiaMatrix(q_grav);
    % M(q) * qdd + G(q) = G(q) => qdd = 0
    qdd_grav = [0 0 0];
    qd_grav = qd_grav + qdd_grav * dt;
    q_grav = q_grav + qd_grav * dt;
    q_hist_grav(i,:) = q_grav;
end

time = (0:steps-1)*dt;

figure;
%subplot(1,1,1)
%plot(time, rad2deg(q_hist_open)); title('Open Loop Response');
%ylabel('Joint Angles (deg)');
%legend('q_1','q_2','q_3'); grid on;
subplot(1,1,1)
plot(time, rad2deg(q_hist_grav)); title('Gravity Compensation');
xlabel('Time (s)'); ylabel('Joint Angles (deg)');
legend('q_1','q_2','q_3'); grid on;

% ---------------------------
% Fonksiyonlar
function Gq = GravityVector(q)
    % (Gerçek modelde q'ya bağlı olur!)
    Gq = [10.6343; 3.4954; 0.4638];
end
function Mq = InertiaMatrix(q)
    % (Gerçek modelde q'ya bağlı olur!)
    Mq = [1.5935 0.8729 0.2063;
          0.8729 0.3878 0.1118;
          0.2063 0.1118 0.0130];
end
