function M = inertia_matrix(q, params)
    % Açılar
    th1 = q(1); th2 = q(2); th3 = q(3);
    a1 = params.a(1); a2 = params.a(2); a3 = params.a(3);
    m1 = params.m(1); m2 = params.m(2); m3 = params.m(3);
    I1 = params.I(1); I2 = params.I(2); I3 = params.I(3);

    % Açılar toplamı
    th12 = th1 + th2;
    th123 = th12 + th3;

    % M matrisini başlat
    M = zeros(3);

    % Bağlantı 1'in katkısı
    M = M + I1 * eye(3);
    M(1,1) = M(1,1) + m1 * (a1/2)^2;

    % Bağlantı 2'nin katkısı
    r2 = a1 + a2/2*cos(th2);
    M(1,1) = M(1,1) + m2 * r2^2;
    M(1,2) = M(1,2) + m2 * r2 * (a2/2*cos(th2));
    M(2,1) = M(1,2);
    M(2,2) = M(2,2) + m2 * (a2/2)^2 + I2;

    % Bağlantı 3'ün katkısı (en sade haliyle)
    rx = a1 + a2*cos(th2) + a3/2*cos(th2 + th3);
    ry = a2/2*cos(th2) + a3/2*cos(th2 + th3);
    rz = a3/2;
    M(1,1) = M(1,1) + m3 * rx^2;
    M(1,2) = M(1,2) + m3 * rx * ry;
    M(1,3) = M(1,3) + m3 * rx * rz;
    M(2,1) = M(1,2);
    M(2,2) = M(2,2) + m3 * ry^2;
    M(2,3) = M(2,3) + m3 * ry * rz;
    M(3,1) = M(1,3);
    M(3,2) = M(2,3);
    M(3,3) = M(3,3) + m3 * rz^2 + I3;
end
