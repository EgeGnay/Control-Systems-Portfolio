clear; clc;

% --- Sistem parametreleri ---
params.a = [1.0; 1.0; 0.8];
params.m = [2.0; 1.5; 1.0];
params.g = 9.81;
params.I = 1/12 * params.m .* params.a.^2;

% --- CTC kazançları ---
Kp = diag([120, 120, 100]);
Kv = diag([30, 30, 20]);

% --- Hedef pozisyon ve hız ---
qd = [pi/4; pi/6; -pi/6];
dqd = [0; 0; 0];
ddqd = [0; 0; 0];  % sabit hedef olduğu için hız ve ivme sıfır

% --- Başlangıç durumu ---
q0 = [0.1; 0.1; -0.1];
dq0 = [0; 0; 0];
x0 = [q0; dq0];

% --- Simülasyon ayarları ---
tspan = [0 5];
rhs = @(t, x) ctc_control_rhs(t, x, qd, dqd, ddqd, Kp, Kv, params);
options = odeset('RelTol',1e-5, 'AbsTol',1e-6, 'MaxStep',0.01);
[t, x] = ode45(rhs, tspan, x0, options);

% --- Pozisyon grafiği ---
figure;
plot(t, x(:,1), 'b', 'LineWidth', 1.5); hold on;
plot(t, x(:,2), 'r', 'LineWidth', 1.5);
plot(t, x(:,3), 'g', 'LineWidth', 1.5);
xlabel('Time [s]'); ylabel('Joint Angles [rad]');
legend('q_1','q_2','q_3'); title('Joint Angles under CTC');
grid on;

% --- Tork hesabı ---
tau = zeros(length(t), 3);
for i = 1:length(t)
    q = x(i,1:3)';
    dq = x(i,4:6)';
    e = qd - q;
    edot = dqd - dq;
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);
    v = ddqd + Kv * edot + Kp * e;
    tau(i,:) = (M * v + Cqdot + G)';
end

% --- Tork grafiği ---
figure;
plot(t, tau(:,1), 'b', 'LineWidth', 1.5); hold on;
plot(t, tau(:,2), 'r', 'LineWidth', 1.5);
plot(t, tau(:,3), 'g', 'LineWidth', 1.5);
xlabel('Time [s]'); ylabel('Torque [Nm]');
legend('\\tau_1','\\tau_2','\\tau_3'); title('Joint Torques under CTC');
grid on;

% --- RMS Hata hesaplama ---
e1_rms = sqrt(mean((x(:,1) - qd(1)).^2));
e2_rms = sqrt(mean((x(:,2) - qd(2)).^2));
e3_rms = sqrt(mean((x(:,3) - qd(3)).^2));

fprintf('\n--- RMS Position Errors (CTC) ---\n');
fprintf('q1 RMS error: %.4f rad\n', e1_rms);
fprintf('q2 RMS error: %.4f rad\n', e2_rms);
fprintf('q3 RMS error: %.4f rad\n', e3_rms);
