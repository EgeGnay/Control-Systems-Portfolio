function dx = ctc_control_rhs(~, x, qd, dqd, ddqd, Kp, Kv, params)
    q = x(1:3);
    dq = x(4:6);

    % Hata tanımları
    e = qd - q;
    edot = dqd - dq;

    % Sanal hızlanma (feedback linearization)
    v = ddqd + Kv * edot + Kp * e;

    % Dinamik terimler
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);

    % Tork
    tau = M * v + Cqdot + G;

    % Eşitlikler
    ddq = M \ (tau - Cqdot - G);  % açık çözüm, net etkiyi al

    dx = [dq; ddq];
end
