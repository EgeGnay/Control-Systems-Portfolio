function dx = impedance_control_rhs_circle(t, x, qd_all, dqd_all, ddqd_all, Kp, Kd, params, t_array)
    q = x(1:3);
    dq = x(4:6);

    % Zaman indeksini al (en yakın)
    [~, idx] = min(abs(t_array - t));

    qd = qd_all(:,idx);
    dqd = dqd_all(:,idx);
    ddqd = ddqd_all(:,idx);

    e = qd - q;
    edot = dqd - dq;
    v = ddqd + Kd * edot + Kp * e;

    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);

    tau = M * v + Cqdot + G;
    ddq = M \ (tau - Cqdot - G);

    dx = [dq; ddq];
end
