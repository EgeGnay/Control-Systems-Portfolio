function G = gravity_vector(q, params)
    theta1 = q(1); theta2 = q(2); theta3 = q(3);
    a = params.a; m = params.m; g = params.g;

    % Açılar toplamı
    th12 = theta1 + theta2;
    th123 = th12 + theta3;

    G = zeros(3,1);
    G(1) = g * cos(theta1) * ...
          (m(1)*a(1)/2 + m(2)*a(1) + m(2)*a(2)/2*cos(theta2) + ...
           m(3)*a(1) + m(3)*a(2)*cos(theta2) + m(3)*a(3)/2*cos(theta2 + theta3));
    G(2) = g * cos(th12) * (m(2)*a(2)/2 + m(3)*a(2) + m(3)*a(3)/2*cos(theta3));
    G(3) = g * cos(th123) * (m(3)*a(3)/2);
end
