function Cqdot = coriolis_matrix(q, dq, params)
    % Kısmi model: yalnızca örnek Coriolis terimleri (PDF'teki haliyle)
    theta2 = q(2);
    dtheta1 = dq(1);
    dtheta2 = dq(2);

    m2 = params.m(2); a1 = params.a(1); a2 = params.a(2);

    c = m2*a1*a2*sin(theta2);
    
    % Coriolis * dq vektörü
    Cqdot = zeros(3,1);
    Cqdot(1) = -c * dtheta2^2 - c * dtheta1 * dtheta2;
    Cqdot(2) =  c * dtheta1^2;
    % Cqdot(3) = 0 zaten PDF'te 3. bileşen boş
end
