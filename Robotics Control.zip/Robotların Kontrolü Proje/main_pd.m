clear; clc;

% --- Sistem parametreleri ---
params.a = [1.0; 1.0; 0.8];             
params.m = [2.0; 1.5; 1.0];             
params.g = 9.81;                        
params.I = 1/12 * params.m .* params.a.^2;

% --- Kazançlar (iyileştirilmiş) ---
Kp = diag([39.8375, 9.695, 0.325]);
Kd = diag([15.935, 3.878, 0.13]);

% --- Hedef pozisyon ve hız ---
q_d = [pi/4; pi/6; -pi/6];
dq_d = [0; 0; 0];

% --- Başlangıç durumu ---
q0 = [0.1; 0.1; -0.1];    
dq0 = [0; 0; 0];
x0 = [q0; dq0];

% --- Simülasyon ayarları ---
tspan = [0 30];
options = odeset('RelTol',1e-5, 'AbsTol',1e-6, 'MaxStep',0.01);
rhs = @(t, x) pd_control_rhs(t, x, q_d, dq_d, Kp, Kd, params);
[t, x] = ode45(rhs, tspan, x0, options);

% --- Pozisyon çizimi ---
figure;
plot(t, x(:,1), 'b', 'LineWidth', 1.5); hold on;
plot(t, x(:,2), 'r', 'LineWidth', 1.5);
plot(t, x(:,3), 'g', 'LineWidth', 1.5);
xlabel('Time [s]'); ylabel('Joint Angles [rad]');
legend('q_1','q_2','q_3'); title('Joint Angles under PD Control');
grid on;

% --- RMS Hata Hesaplama ---
e1_rms = sqrt(mean((x(:,1) - q_d(1)).^2));
e2_rms = sqrt(mean((x(:,2) - q_d(2)).^2));
e3_rms = sqrt(mean((x(:,3) - q_d(3)).^2));

fprintf('\n--- RMS Position Errors ---\n');
fprintf('q1 RMS error: %.4f rad\n', e1_rms);
fprintf('q2 RMS error: %.4f rad\n', e2_rms);
fprintf('q3 RMS error: %.4f rad\n', e3_rms);

% --- Tork hesaplama ve çizim ---
tau = zeros(length(t), 3);
for i = 1:length(t)
    q = x(i,1:3)';
    dq = x(i,4:6)';
    e = q_d - q;
    edot = dq_d - dq;
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);
    tau(i,:) = (Kp * e + Kd * edot)' * M + Cqdot' + G';
end

% Tork çizimi
figure;
plot(t, tau(:,1), 'b', 'LineWidth', 1.5); hold on;
plot(t, tau(:,2), 'r', 'LineWidth', 1.5);
plot(t, tau(:,3), 'g', 'LineWidth', 1.5);
xlabel('Time [s]'); ylabel('Torque [Nm]');
legend('\tau_1','\tau_2','\tau_3'); title('Joint Torques under PD Control');
grid on;

