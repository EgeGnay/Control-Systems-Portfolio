% RRR Manipülatör: Open Loop vs Gravity Compensation
% Task space RMSE analizi dahil

clc; clear; close all;

% --- Parametreler ---
a1 = 1.0; a2 = 1.0; a3 = 0.8;         % Link lengths (m)
m1 = 2.0; m2 = 1.5; m3 = 1.0;         % Link masses (kg)
g = 9.81;                             % Gravity (m/s^2)

q0 = deg2rad([14 5 -9]);              % Initial joint angles (rad)
qd0 = [0 0 0];                        % Initial joint velocities (rad/s)
dt = 0.01; T = 5; steps = T/dt;       % Simülasyon zamanı

% Sonuç kayıt matrisleri
q_hist_open  = zeros(steps,3);
q_hist_grav  = zeros(steps,3);
x_hist_open  = zeros(steps,3); % [x, y, phi]
x_hist_grav  = zeros(steps,3);

q_open = q0;    qd_open = qd0;
q_grav = q0;    qd_grav = qd0;

for i = 1:steps
    % --- Open Loop (tau = 0) ---
    Gq_open = GravityVector(q_open, a1, a2, a3, m1, m2, m3, g);
    Mq_open = InertiaMatrix(q_open); % Sabit veya q'ya bağlı fonksiyonunla değiştir
    qdd_open = -Mq_open \ Gq_open;
    qd_open = qd_open + qdd_open' * dt;
    q_open = q_open + qd_open * dt;
    q_hist_open(i,:) = q_open;
    x_hist_open(i,:) = forwardKinematics(q_open, a1, a2, a3);

    % --- Gravity Compensation (tau = G(q)) ---
    % M(q)*qdd + G(q) = G(q) => qdd = 0
    qdd_grav = [0 0 0];
    qd_grav = qd_grav + qdd_grav * dt;
    q_grav = q_grav + qd_grav * dt;
    q_hist_grav(i,:) = q_grav;
    x_hist_grav(i,:) = forwardKinematics(q_grav, a1, a2, a3);
end

time = (0:steps-1)*dt;

%% Joint space grafikleri
figure;
subplot(2,1,1)
plot(time, rad2deg(q_hist_open)); title('Open Loop - Joint Angles');
ylabel('Joint Angles (deg)');
legend('q_1','q_2','q_3'); grid on;
subplot(2,1,2)
plot(time, rad2deg(q_hist_grav)); title('Gravity Compensation - Joint Angles');
xlabel('Time (s)'); ylabel('Joint Angles (deg)');
legend('q_1','q_2','q_3'); grid on;

%% Task space (uç efektör) grafikleri
figure;
subplot(2,1,1)
plot(time, x_hist_open); title('Open Loop - End-Effector (Task Space)');
ylabel('Position (m) / Orientation (rad)');
legend('x','y','\phi'); grid on;
subplot(2,1,2)
plot(time, x_hist_grav); title('Gravity Compensation - End-Effector (Task Space)');
xlabel('Time (s)');
ylabel('Position (m) / Orientation (rad)');
legend('x','y','\phi'); grid on;

%% End-Effector Path (Ayrı Figürler)
figure;
plot(x_hist_open(:,1), x_hist_open(:,2), 'r', 'LineWidth', 1.5); hold on;
plot(x_hist_open(1,1), x_hist_open(1,2), 'ko', 'MarkerFaceColor', 'g');
xlabel('x (m)'); ylabel('y (m)');
title('End-Effector Path in Task Space - Open Loop');
grid on; legend('Open Loop','Start');

figure;
plot(x_hist_grav(:,1), x_hist_grav(:,2), 'b', 'LineWidth', 1.5); hold on;
plot(x_hist_grav(1,1), x_hist_grav(1,2), 'ko', 'MarkerFaceColor', 'g');
xlabel('x (m)'); ylabel('y (m)');
title('End-Effector Path in Task Space - Gravity Compensation');
grid on; legend('Gravity Compensation','Start');

%% RMSE Hesaplaması (Task space, x-y)
x0_open = x_hist_open(1,1); y0_open = x_hist_open(1,2);
x0_grav = x_hist_grav(1,1); y0_grav = x_hist_grav(1,2);

err_open = sqrt((x_hist_open(:,1) - x0_open).^2 + (x_hist_open(:,2) - y0_open).^2);
err_grav = sqrt((x_hist_grav(:,1) - x0_grav).^2 + (x_hist_grav(:,2) - y0_grav).^2);

RMSE_open = sqrt(mean(err_open.^2));
RMSE_grav = sqrt(mean(err_grav.^2));

fprintf('Open Loop RMS End-Effector Error: %.6f m\n', RMSE_open);
fprintf('Gravity Compensation RMS End-Effector Error: %.6f m\n', RMSE_grav);

%% Hataların zamana göre grafiği
figure;
plot(time, err_open, 'r'); hold on;
plot(time, err_grav, 'b');
legend('Open Loop', 'Gravity Compensation');
xlabel('Time (s)'); ylabel('End-Effector Error (m)');
title('Instantaneous End-Effector Error');
grid on;

%% --- Fonksiyonlar ---

function Gq = GravityVector(q, a1, a2, a3, m1, m2, m3, g)
    % Gravity vektörü (q'ya bağlı, planar manipülatör için)
    q1 = q(1); q2 = q(2); q3 = q(3);
    G1 = (m1*a1/2 + m2*a1 + m2*a2/2*cos(q2) + m3*a1 + m3*a2*cos(q2) + m3*a3/2*cos(q2+q3)) * g * cos(q1);
    G2 = (m2*a2/2 + m3*a2 + m3*a3/2*cos(q3)) * g * cos(q1+q2);
    G3 = (m3*a3/2) * g * cos(q1+q2+q3);
    Gq = [G1; G2; G3];
end

function Mq = InertiaMatrix(q)
    % Sadece örnek olarak sabit matris veriyorum, istersen q'ya bağlı fonksiyonunu yazabilirsin!
    Mq = [1.5935 0.8729 0.2063;
          0.8729 0.3878 0.1118;
          0.2063 0.1118 0.0130];
end

function x = forwardKinematics(q, a1, a2, a3)
    % Planar RRR manipülatör için uç efektör pozisyonu ve yönelimi
    q1 = q(1); q2 = q(2); q3 = q(3);
    x_val = a1*cos(q1) + a2*cos(q1+q2) + a3*cos(q1+q2+q3);
    y_val = a1*sin(q1) + a2*sin(q1+q2) + a3*sin(q1+q2+q3);
    phi_val = q1 + q2 + q3;
    x = [x_val, y_val, phi_val];
end
