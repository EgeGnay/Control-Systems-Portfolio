function dx = pd_control_rhs(~, x, qd, dqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Hata terimleri
    e = qd - q;
    edot = dqd - dq;

    % PD kontrol kuvveti
    tau = Kp * e + Kd * edot;

    % Dinamik ifadeler
    M = inertia_matrix(q, params);
    Cqdot = coriolis_matrix(q, dq, params);
    G = gravity_vector(q, params);

    ddq = M \ (tau - Cqdot - G);

    dx = [dq; ddq];
end
