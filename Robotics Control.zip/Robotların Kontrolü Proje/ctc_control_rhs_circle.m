function dx = ctc_control_rhs_circle(t, x, qd, dqd, ddqd, Kp, Kd, params)
    q = x(1:3);
    dq = x(4:6);

    % Time index (safe)
    dt = 0.01;
    idx = min(size(qd,2), max(1, round(t / dt) + 1));
    
    q_d = qd(:,idx);
    dq_d = dqd(:,idx);
    ddq_d = ddqd(:,idx);

    e = q_d - q;
    edot = dq_d - dq;
    v = ddq_d + Kd*edot + Kp*e;

    M = inertia_matrix(q, params);
    C = zeros(3,1); % Optional: add coriolis_matrix(q,dq,params) if needed
    G = gravity_vector(q, params);

    tau = M*v + C + G;
    ddq = M \ (tau - C - G);

    dx = [dq; ddq];
end
