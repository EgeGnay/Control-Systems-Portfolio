% Zaman vektörü oluşturma
t0 = 0;          % Başlangıç zamanı
t_end = 300;      % Bitiş zamanı
dt = 0.01;       % Örnekleme aralığı
time = t0:dt:t_end; % Zaman vektörü

% Hata hesaplama
e1 = out.reference - out.FPID49;    % Referans ve FPID49 arasındaki fark
e2 = out.reference - out.FPID9;     % Referans ve FPID9 arasındaki fark
e3 = out.reference - out.FPID_D9;   % Referans ve FPID-D9 arasındaki fark

% Hataların mutlak değerleri
abs_e1 = abs(e1);
abs_e2 = abs(e2);
abs_e3 = abs(e3);

% IAE Hesaplama (trapz ile integral)
IAE1 = trapz(time, abs_e1); % FPID49 için IAE
IAE2 = trapz(time, abs_e2); % FPID9 için IAE
IAE3 = trapz(time, abs_e3); % FPID-D9 için IAE

% Sonuçları görüntüleme
disp(['IAE1 (FPID49): ', num2str(IAE1)]);
disp(['IAE2 (FPID9): ', num2str(IAE2)]);
disp(['IAE3 (FPID-D9): ', num2str(IAE3)]);

% Çıktıları referans sinyali ile karşılaştırma
figure;

% FPID49 Çıktısı ve Referans
subplot(3, 1, 1);
plot(time, out.reference, 'k--', 'LineWidth', 1.5); hold on;
plot(time, out.FPID49, 'b', 'LineWidth', 1.5);
title('FPID49 Output vs Reference');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Reference', 'FPID49 Output');
grid on;

% FPID9 Çıktısı ve Referans
subplot(3, 1, 2);
plot(time, out.reference, 'k--', 'LineWidth', 1.5); hold on;
plot(time, out.FPID9, 'r', 'LineWidth', 1.5);
title('FPID9 Output vs Reference');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Reference', 'FPID9 Output');
grid on;

% FPID-D9 Çıktısı ve Referans
subplot(3, 1, 3);
plot(time, out.reference, 'k--', 'LineWidth', 1.5); hold on;
plot(time, out.FPID_D9, 'g', 'LineWidth', 1.5);
title('FPID-D9 Output vs Reference');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Reference', 'FPID-D9 Output');
grid on;

% Grafik penceresi genel başlık
sgtitle('Reference vs Outputs for Different Configurations');

